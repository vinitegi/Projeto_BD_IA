create procedure sp_abrir_chamado(IN p_aluno_id integer, IN p_disciplina_id integer, IN p_assunto character varying, IN p_descricao text, OUT p_chamado_id integer)
    language plpgsql
as
$$
BEGIN
    IF p_assunto IS NULL OR TRIM(p_assunto) = '' THEN
        RAISE EXCEPTION 'Assunto do chamado e obrigatorio';
    END IF;

    INSERT INTO chamados (aluno_id, disciplina_id, assunto, descricao)
    VALUES (p_aluno_id, p_disciplina_id, p_assunto, COALESCE(p_descricao, ''))
    RETURNING id INTO p_chamado_id;
END;
$$;

alter procedure sp_abrir_chamado(integer, integer, varchar, text, out integer) owner to postgres;

