create function fn_situacao(p_media numeric, p_faltas integer, p_total_aulas integer) returns character varying
    immutable
    language plpgsql
as
$$
BEGIN
    IF p_faltas > p_total_aulas * 0.25 THEN
        RETURN 'REPROVADO POR FALTAS';
    ELSIF p_media IS NULL THEN
        RETURN 'SEM NOTAS';
    ELSIF p_media >= 6.00 THEN
        RETURN 'REGULAR';
    ELSE
        RETURN 'EM RISCO';
    END IF;
END;
$$;

alter function fn_situacao(numeric, integer, integer) owner to postgres;

