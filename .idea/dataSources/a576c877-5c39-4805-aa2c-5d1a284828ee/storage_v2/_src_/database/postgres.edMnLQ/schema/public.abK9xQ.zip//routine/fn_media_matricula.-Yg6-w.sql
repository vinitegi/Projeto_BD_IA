create function fn_media_matricula(p_matricula_id integer) returns numeric
    stable
    language sql
as
$$
    SELECT ROUND(SUM(valor * peso) / SUM(peso), 2)
      FROM notas
     WHERE matricula_id = p_matricula_id;
$$;

alter function fn_media_matricula(integer) owner to postgres;

