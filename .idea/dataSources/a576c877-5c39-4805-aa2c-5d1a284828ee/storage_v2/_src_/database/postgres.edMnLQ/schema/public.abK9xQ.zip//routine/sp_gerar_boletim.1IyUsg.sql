create function sp_gerar_boletim(p_aluno_id integer, p_semestre character varying DEFAULT NULL::character varying)
    returns TABLE(codigo character varying, disciplina character varying, semestre character varying, media numeric, faltas integer, total_aulas integer, situacao character varying)
    stable
    language sql
as
$$
    SELECT d.codigo,
           d.nome,
           m.semestre,
           fn_media_matricula(m.id),
           m.faltas,
           d.total_aulas,
           fn_situacao(fn_media_matricula(m.id), m.faltas, d.total_aulas)
      FROM matriculas m
      JOIN disciplinas d ON d.id = m.disciplina_id
     WHERE m.aluno_id = p_aluno_id
       AND (p_semestre IS NULL OR p_semestre = '' OR m.semestre = p_semestre)
     ORDER BY d.nome;
$$;

alter function sp_gerar_boletim(integer, varchar) owner to postgres;

