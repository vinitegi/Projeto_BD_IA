create procedure sp_calcular_media(IN p_matricula_id integer, OUT p_media numeric, OUT p_situacao character varying)
    language plpgsql
as
$$
DECLARE
    v_faltas INT;
    v_total  INT;
BEGIN
    SELECT m.faltas, d.total_aulas
      INTO v_faltas, v_total
      FROM matriculas m
      JOIN disciplinas d ON d.id = m.disciplina_id
     WHERE m.id = p_matricula_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Matricula % inexistente', p_matricula_id;
    END IF;

    p_media    := fn_media_matricula(p_matricula_id);
    p_situacao := fn_situacao(p_media, v_faltas, v_total);
END;
$$;

alter procedure sp_calcular_media(integer, out numeric, out varchar) owner to postgres;

