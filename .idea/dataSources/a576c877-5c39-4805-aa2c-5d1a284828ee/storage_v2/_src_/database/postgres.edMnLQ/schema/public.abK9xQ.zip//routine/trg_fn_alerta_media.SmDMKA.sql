create function trg_fn_alerta_media() returns trigger
    language plpgsql
as
$$
BEGIN
    PERFORM fn_verificar_alerta_media(NEW.matricula_id);
    RETURN NEW;
END;
$$;

alter function trg_fn_alerta_media() owner to postgres;

