create function trg_fn_auditoria_notas() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF OLD.valor IS DISTINCT FROM NEW.valor OR OLD.peso IS DISTINCT FROM NEW.peso THEN
            INSERT INTO log_alteracao_notas
                (nota_id, matricula_id, avaliacao, operacao,
                 valor_antigo, valor_novo, peso_antigo, peso_novo, usuario)
            VALUES
                (OLD.id, OLD.matricula_id, OLD.avaliacao, 'UPDATE',
                 OLD.valor, NEW.valor, OLD.peso, NEW.peso, CURRENT_USER);
        END IF;
        RETURN NEW;
    ELSE  -- DELETE
        INSERT INTO log_alteracao_notas
            (nota_id, matricula_id, avaliacao, operacao,
             valor_antigo, valor_novo, peso_antigo, peso_novo, usuario)
        VALUES
            (OLD.id, OLD.matricula_id, OLD.avaliacao, 'DELETE',
             OLD.valor, NULL, OLD.peso, NULL, CURRENT_USER);
        RETURN OLD;
    END IF;
END;
$$;

alter function trg_fn_auditoria_notas() owner to postgres;

