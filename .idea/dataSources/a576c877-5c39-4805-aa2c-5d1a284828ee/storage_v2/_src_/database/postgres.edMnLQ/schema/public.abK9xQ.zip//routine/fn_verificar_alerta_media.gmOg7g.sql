create function fn_verificar_alerta_media(p_matricula_id integer) returns void
    language plpgsql
as
$$
DECLARE
    v_media      NUMERIC(4,2);
    v_aluno      INT;
    v_disciplina VARCHAR;
    v_msg        VARCHAR;
BEGIN
    v_media := fn_media_matricula(p_matricula_id);

    IF v_media IS NOT NULL AND v_media < 6.00 THEN
        SELECT m.aluno_id, d.nome
          INTO v_aluno, v_disciplina
          FROM matriculas m
          JOIN disciplinas d ON d.id = m.disciplina_id
         WHERE m.id = p_matricula_id;

        v_msg := 'Sua media parcial em ' || v_disciplina || ' esta em ' || v_media
                 || ', abaixo da minima de 6.00.';

        UPDATE alertas
           SET media = v_media, mensagem = v_msg, criado_em = NOW()
         WHERE matricula_id = p_matricula_id AND tipo = 'MEDIA_BAIXA' AND ativo;

        IF NOT FOUND THEN
            INSERT INTO alertas (aluno_id, matricula_id, tipo, mensagem, media)
            VALUES (v_aluno, p_matricula_id, 'MEDIA_BAIXA', v_msg, v_media);
        END IF;
    ELSE
        UPDATE alertas SET ativo = FALSE
         WHERE matricula_id = p_matricula_id AND tipo = 'MEDIA_BAIXA' AND ativo;
    END IF;
END;
$$;

alter function fn_verificar_alerta_media(integer) owner to postgres;

